import sys, os

ROOT_DIR = "\\".join(os.path.dirname(__file__).split("\\")[:-1])

host = "localhost"
port = 30080

SRU_VERSION = "0.1.0"
