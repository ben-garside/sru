
host = "localhost"
port = 30080

SRU_VERSION = "0.1.0"
